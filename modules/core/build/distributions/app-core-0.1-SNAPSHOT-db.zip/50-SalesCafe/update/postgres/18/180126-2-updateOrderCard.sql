alter table SALESCAFE_ORDER_CARD drop column AMOUNT cascade ;
alter table SALESCAFE_ORDER_CARD add column AMOUNT integer ;
