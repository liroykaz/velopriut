alter table SALESCAFE_ORDER_CARD add column PRODUCT_ID uuid ;
