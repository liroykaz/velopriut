alter table SALESCAFE_PRODUCT drop column WEIGHT__UNUSED cascade ;
