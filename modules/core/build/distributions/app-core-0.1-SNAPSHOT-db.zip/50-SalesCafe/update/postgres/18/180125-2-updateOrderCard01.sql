alter table SALESCAFE_ORDER_CARD add column ORDER_STATUS integer ;
