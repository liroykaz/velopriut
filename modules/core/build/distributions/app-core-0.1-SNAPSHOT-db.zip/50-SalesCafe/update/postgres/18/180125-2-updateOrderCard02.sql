alter table SALESCAFE_ORDER_CARD drop column ORDER_STATUS cascade ;
