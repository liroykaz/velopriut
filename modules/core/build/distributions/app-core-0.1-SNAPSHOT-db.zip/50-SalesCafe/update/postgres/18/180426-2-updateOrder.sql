alter table SALESCAFE_ORDER add column WORK_DAY_ID uuid ;
