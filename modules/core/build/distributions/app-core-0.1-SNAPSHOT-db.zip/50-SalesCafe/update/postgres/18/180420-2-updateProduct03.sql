alter table SALESCAFE_PRODUCT rename column is_not_available to is_not_available__UNUSED ;
alter table SALESCAFE_PRODUCT add column IS_AVAILABLE boolean ;
