alter table SALESCAFE_WORK_DAY add column DAY_OF_WEEK integer ;
