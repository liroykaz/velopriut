alter table SALESCAFE_PRODUCT add column WEIGHT integer ;
