alter table SALESCAFE_PRODUCT rename column weight to weight__UNUSED ;
