alter table SALESCAFE_PRODUCT drop column ORDER_CARD_ID cascade ;
