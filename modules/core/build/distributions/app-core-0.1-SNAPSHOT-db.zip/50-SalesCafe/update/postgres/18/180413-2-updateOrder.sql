alter table SALESCAFE_ORDER rename column number_of_order to number_of_order__UNUSED ;
alter table SALESCAFE_ORDER add column NUMBER_OF_ORDER integer ;
