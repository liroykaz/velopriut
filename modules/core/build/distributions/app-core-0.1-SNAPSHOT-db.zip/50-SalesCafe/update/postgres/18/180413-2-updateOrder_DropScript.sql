alter table SALESCAFE_ORDER drop column NUMBER_OF_ORDER__UNUSED cascade ;
