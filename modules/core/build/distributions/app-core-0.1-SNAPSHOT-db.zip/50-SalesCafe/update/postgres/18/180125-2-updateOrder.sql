alter table SALESCAFE_ORDER add column ORDER_STATUS varchar(255) ;
