alter table SALESCAFE_ORDER drop column ORDER_STATUS cascade ;
alter table SALESCAFE_ORDER add column ORDER_STATUS integer ;
