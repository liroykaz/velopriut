alter table SALESCAFE_ORDER add column TYPE_OF_CUSTOMER integer ;
