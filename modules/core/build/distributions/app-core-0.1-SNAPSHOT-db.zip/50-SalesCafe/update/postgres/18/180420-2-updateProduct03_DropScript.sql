alter table SALESCAFE_PRODUCT drop column IS_NOT_AVAILABLE__UNUSED cascade ;
